package com.example.reliance.real_time_crime_monitoring;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
public class View_posts extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_posts);
    }
}
