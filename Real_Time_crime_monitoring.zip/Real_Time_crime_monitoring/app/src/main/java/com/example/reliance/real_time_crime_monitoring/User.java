package com.example.reliance.real_time_crime_monitoring;

public class User {

    private String type;
    private  String desc;
    public  User()
    {}

    public  User(String type,String desc)
    {
        type=this.type;
        desc=this.desc;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
